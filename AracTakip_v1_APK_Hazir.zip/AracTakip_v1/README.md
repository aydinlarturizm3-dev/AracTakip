# Araç Takip v1.0

Android araç belge ve süre takip uygulaması.

## Alanlar
Plaka, marka, model, trafik poliçesi, kasko poliçesi, koltuk sigortası ve muayene.

## Uyarılar
- Muayene: 30 gün kala
- Trafik, kasko ve koltuk sigortası: 7 gün kala
- Süresi geçen kayıtlar ayrı ekranda gösterilir.

## APK
APK oluşturma adımları için `BUILD_APK.md` dosyasına bakın.
