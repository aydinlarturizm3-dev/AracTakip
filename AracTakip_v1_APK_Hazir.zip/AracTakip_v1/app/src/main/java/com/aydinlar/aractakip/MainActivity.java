package com.aydinlar.aractakip;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private VehicleDb db;
    private LinearLayout content;
    private final SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy", new Locale("tr", "TR"));

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new VehicleDb(this);
        ReminderUtil.schedule(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
        showHome();
    }

    private void buildShell(String title) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(247, 248, 250));
        root.setPadding(dp(16), dp(16), dp(16), dp(12));

        TextView app = text("ARAÇ TAKİP", 24, true); app.setTextColor(Color.rgb(20, 45, 75));
        root.addView(app);
        TextView sub = text(title, 15, false); sub.setTextColor(Color.DKGRAY); sub.setPadding(0, dp(2), 0, dp(12)); root.addView(sub);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(0, 0, 0, dp(12));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setGravity(Gravity.CENTER);
        nav.addView(navButton("Ana Sayfa", v -> showHome()), weight());
        nav.addView(navButton("Araçlar", v -> showVehicles()), weight());
        nav.addView(navButton("Yaklaşan", v -> showUpcoming()), weight());
        nav.addView(navButton("Geçenler", v -> showOverdue()), weight());
        root.addView(nav);
        setContentView(root);
    }

    private void showHome() {
        buildShell("Genel Durum");
        List<Vehicle> list = db.all();
        int upcoming = 0, overdue = 0;
        for (Vehicle v : list) {
            if (hasOverdue(v)) overdue++;
            else if (hasUpcoming(v)) upcoming++;
        }
        content.addView(summaryCard("Toplam Araç", String.valueOf(list.size())));
        content.addView(summaryCard("Yaklaşan Süreler", String.valueOf(upcoming)));
        content.addView(summaryCard("Süresi Geçen Araçlar", String.valueOf(overdue)));
        Button add = primaryButton("+ Yeni Araç Ekle"); add.setOnClickListener(v -> editVehicle(null)); content.addView(add);
        TextView note = text("Muayene uyarısı 30 gün, poliçe uyarıları 7 gün kala başlar.", 14, false);
        note.setPadding(dp(4), dp(18), dp(4), 0); note.setTextColor(Color.DKGRAY); content.addView(note);
    }

    private void showVehicles() {
        buildShell("Araçlar");
        Button add = primaryButton("+ Yeni Araç Ekle"); add.setOnClickListener(v -> editVehicle(null)); content.addView(add);
        List<Vehicle> list = db.all();
        if (list.isEmpty()) empty("Henüz araç kaydı yok.");
        for (Vehicle v : list) content.addView(vehicleCard(v));
    }

    private void showUpcoming() {
        buildShell("Yaklaşan Süreler");
        boolean any = false;
        for (Vehicle v : db.all()) {
            LinearLayout card = warningCardFor(v, false);
            if (card != null) { content.addView(card); any = true; }
        }
        if (!any) empty("Yaklaşan belge veya muayene süresi yok.");
    }

    private void showOverdue() {
        buildShell("Süresi Geçenler");
        boolean any = false;
        for (Vehicle v : db.all()) {
            LinearLayout card = warningCardFor(v, true);
            if (card != null) { content.addView(card); any = true; }
        }
        if (!any) empty("Süresi geçmiş kayıt yok.");
    }

    private LinearLayout warningCardFor(Vehicle v, boolean overdueOnly) {
        LinearLayout card = card();
        TextView head = text(v.plate + "  •  " + safe(v.brand) + " " + safe(v.model), 17, true); card.addView(head);
        boolean added = false;
        added |= addStatus(card, "Muayene", v.inspectionExpiry, 30, overdueOnly);
        added |= addStatus(card, "Trafik Poliçesi", v.trafficExpiry, 7, overdueOnly);
        added |= addStatus(card, "Kasko Poliçesi", v.cascoExpiry, 7, overdueOnly);
        added |= addStatus(card, "Koltuk Sigortası", v.seatExpiry, 7, overdueOnly);
        if (!added) return null;
        card.setOnClickListener(x -> editVehicle(v));
        return card;
    }

    private boolean addStatus(LinearLayout card, String label, long expiry, int threshold, boolean overdueOnly) {
        if (expiry <= 0) return false;
        long days = daysUntil(expiry);
        boolean match = overdueOnly ? days < 0 : days >= 0 && days <= threshold;
        if (!match) return false;
        String s = days < 0 ? "SÜRESİ GEÇTİ • " + (-days) + " gün" : days == 0 ? "BUGÜN BİTİYOR" : days + " gün kaldı";
        TextView t = text(label + ": " + format(expiry) + "  —  " + s, 14, days <= 0); t.setPadding(0, dp(8), 0, 0);
        t.setTextColor(days <= 0 ? Color.rgb(180, 35, 35) : Color.rgb(180, 105, 0)); card.addView(t);
        return true;
    }

    private View vehicleCard(Vehicle v) {
        LinearLayout card = card();
        TextView head = text(v.plate, 19, true); head.setTextColor(Color.rgb(20,45,75)); card.addView(head);
        card.addView(text(safe(v.brand) + " " + safe(v.model), 15, false));
        card.addView(text("Muayene: " + format(v.inspectionExpiry), 14, false));
        card.addView(text("Trafik: " + format(v.trafficExpiry), 14, false));
        card.addView(text("Kasko: " + format(v.cascoExpiry), 14, false));
        card.addView(text("Koltuk: " + format(v.seatExpiry), 14, false));
        card.setOnClickListener(x -> editVehicle(v));
        return card;
    }

    private void editVehicle(Vehicle existing) {
        buildShell(existing == null ? "Yeni Araç" : "Araç Düzenle");
        EditText plate = field("Plaka"); EditText brand = field("Marka"); EditText model = field("Model");
        content.addView(label("Plaka")); content.addView(plate); content.addView(label("Marka")); content.addView(brand); content.addView(label("Model")); content.addView(model);
        final long[] traffic = {0}, casco = {0}, seat = {0}, inspection = {0};
        if (existing != null) {
            plate.setText(existing.plate); brand.setText(existing.brand); model.setText(existing.model);
            traffic[0]=existing.trafficExpiry; casco[0]=existing.cascoExpiry; seat[0]=existing.seatExpiry; inspection[0]=existing.inspectionExpiry;
        }
        Button trafficBtn = dateButton("Trafik Poliçesi Bitiş", traffic); Button cascoBtn = dateButton("Kasko Poliçesi Bitiş", casco);
        Button seatBtn = dateButton("Koltuk Sigortası Bitiş", seat); Button inspectionBtn = dateButton("Muayene Bitiş", inspection);
        content.addView(trafficBtn); content.addView(cascoBtn); content.addView(seatBtn); content.addView(inspectionBtn);

        Button save = primaryButton("Kaydet"); save.setOnClickListener(v -> {
            String p = plate.getText().toString().trim().toUpperCase(new Locale("tr", "TR"));
            if (p.isEmpty()) { Toast.makeText(this, "Plaka zorunludur.", Toast.LENGTH_SHORT).show(); return; }
            Vehicle x = existing == null ? new Vehicle() : existing;
            x.plate=p; x.brand=brand.getText().toString().trim(); x.model=model.getText().toString().trim();
            x.trafficExpiry=traffic[0]; x.cascoExpiry=casco[0]; x.seatExpiry=seat[0]; x.inspectionExpiry=inspection[0];
            db.save(x); Toast.makeText(this, "Araç kaydedildi.", Toast.LENGTH_SHORT).show(); showVehicles();
        }); content.addView(save);
        if (existing != null) {
            Button del = secondaryButton("Aracı Sil"); del.setOnClickListener(v -> { db.delete(existing.id); Toast.makeText(this, "Araç silindi.", Toast.LENGTH_SHORT).show(); showVehicles(); }); content.addView(del);
        }
    }

    private Button dateButton(String title, long[] holder) {
        Button b = secondaryButton(title + ": " + format(holder[0]));
        b.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance(); if (holder[0] > 0) c.setTimeInMillis(holder[0]);
            new DatePickerDialog(this, (view, y, m, d) -> {
                Calendar n = Calendar.getInstance(); n.set(y,m,d,12,0,0); n.set(Calendar.MILLISECOND,0); holder[0]=n.getTimeInMillis();
                b.setText(title + ": " + format(holder[0]));
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });
        return b;
    }

    private boolean hasUpcoming(Vehicle v) { return upcoming(v.inspectionExpiry,30)||upcoming(v.trafficExpiry,7)||upcoming(v.cascoExpiry,7)||upcoming(v.seatExpiry,7); }
    private boolean hasOverdue(Vehicle v) { return overdue(v.inspectionExpiry)||overdue(v.trafficExpiry)||overdue(v.cascoExpiry)||overdue(v.seatExpiry); }
    private boolean upcoming(long date,int limit){ if(date<=0)return false; long d=daysUntil(date); return d>=0&&d<=limit; }
    private boolean overdue(long date){ return date>0&&daysUntil(date)<0; }
    private long daysUntil(long millis){ LocalDate today=LocalDate.now(); LocalDate d=Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate(); return ChronoUnit.DAYS.between(today,d); }
    private String format(long millis){ return millis<=0?"Tarih seçilmedi":df.format(new Date(millis)); }

    private LinearLayout summaryCard(String title, String number) { LinearLayout c=card(); c.addView(text(number,30,true)); TextView t=text(title,15,false); t.setTextColor(Color.DKGRAY); c.addView(t); return c; }
    private LinearLayout card(){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(16),dp(14),dp(16),dp(14)); c.setBackgroundColor(Color.WHITE); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(6),0,dp(6)); c.setLayoutParams(p); c.setElevation(dp(2)); return c; }
    private TextView label(String s){ TextView t=text(s,13,true); t.setPadding(dp(2),dp(10),0,dp(3)); t.setTextColor(Color.DKGRAY); return t; }
    private EditText field(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true); e.setTextSize(16); return e; }
    private TextView text(String s,int size,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(30,30,30)); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private Button navButton(String s, View.OnClickListener l){ Button b=new Button(this); b.setText(s); b.setTextSize(11); b.setAllCaps(false); b.setOnClickListener(l); return b; }
    private Button primaryButton(String s){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextSize(16); b.setTextColor(Color.WHITE); b.setBackgroundColor(Color.rgb(20,70,120)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52)); p.setMargins(0,dp(10),0,dp(4)); b.setLayoutParams(p); return b; }
    private Button secondaryButton(String s){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextSize(15); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52)); p.setMargins(0,dp(6),0,dp(2)); b.setLayoutParams(p); return b; }
    private LinearLayout.LayoutParams weight(){ return new LinearLayout.LayoutParams(0,dp(52),1); }
    private void empty(String s){ TextView t=text(s,16,false); t.setGravity(Gravity.CENTER); t.setPadding(0,dp(40),0,0); t.setTextColor(Color.GRAY); content.addView(t); }
    private int dp(int v){ return Math.round(v*getResources().getDisplayMetrics().density); }
    private String safe(String s){ return s==null?"":s; }
}
