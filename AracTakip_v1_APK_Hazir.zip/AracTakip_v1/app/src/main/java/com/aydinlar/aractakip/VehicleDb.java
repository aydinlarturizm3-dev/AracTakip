package com.aydinlar.aractakip;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class VehicleDb extends SQLiteOpenHelper {
    private static final String DB_NAME = "vehicles.db";
    private static final int DB_VERSION = 1;

    public VehicleDb(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE vehicles (id INTEGER PRIMARY KEY AUTOINCREMENT, plate TEXT NOT NULL, brand TEXT, model TEXT, traffic_expiry INTEGER, casco_expiry INTEGER, seat_expiry INTEGER, inspection_expiry INTEGER)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    public long save(Vehicle v) {
        ContentValues c = new ContentValues();
        c.put("plate", v.plate); c.put("brand", v.brand); c.put("model", v.model);
        c.put("traffic_expiry", v.trafficExpiry); c.put("casco_expiry", v.cascoExpiry);
        c.put("seat_expiry", v.seatExpiry); c.put("inspection_expiry", v.inspectionExpiry);
        SQLiteDatabase db = getWritableDatabase();
        if (v.id > 0) {
            db.update("vehicles", c, "id=?", new String[]{String.valueOf(v.id)});
            return v.id;
        }
        return db.insert("vehicles", null, c);
    }

    public void delete(long id) { getWritableDatabase().delete("vehicles", "id=?", new String[]{String.valueOf(id)}); }

    public List<Vehicle> all() {
        List<Vehicle> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT * FROM vehicles ORDER BY plate COLLATE NOCASE", null);
        try {
            while (c.moveToNext()) {
                Vehicle v = new Vehicle();
                v.id = c.getLong(c.getColumnIndexOrThrow("id"));
                v.plate = c.getString(c.getColumnIndexOrThrow("plate"));
                v.brand = c.getString(c.getColumnIndexOrThrow("brand"));
                v.model = c.getString(c.getColumnIndexOrThrow("model"));
                v.trafficExpiry = c.getLong(c.getColumnIndexOrThrow("traffic_expiry"));
                v.cascoExpiry = c.getLong(c.getColumnIndexOrThrow("casco_expiry"));
                v.seatExpiry = c.getLong(c.getColumnIndexOrThrow("seat_expiry"));
                v.inspectionExpiry = c.getLong(c.getColumnIndexOrThrow("inspection_expiry"));
                out.add(v);
            }
        } finally { c.close(); }
        return out;
    }
}
