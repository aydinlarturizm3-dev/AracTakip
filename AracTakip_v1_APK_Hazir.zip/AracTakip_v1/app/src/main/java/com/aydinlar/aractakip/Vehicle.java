package com.aydinlar.aractakip;

public class Vehicle {
    public long id;
    public String plate;
    public String brand;
    public String model;
    public long trafficExpiry;
    public long cascoExpiry;
    public long seatExpiry;
    public long inspectionExpiry;
}
