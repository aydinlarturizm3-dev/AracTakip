package com.aydinlar.aractakip;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "expiry_alerts";

    @Override public void onReceive(Context context, Intent intent) {
        List<Vehicle> vehicles = new VehicleDb(context).all();
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Belge Uyarıları", NotificationManager.IMPORTANCE_HIGH));
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;

        int id = 1000;
        for (Vehicle v : vehicles) {
            id = notifyIfNeeded(context, nm, v, "Muayene", v.inspectionExpiry, 30, id);
            id = notifyIfNeeded(context, nm, v, "Trafik poliçesi", v.trafficExpiry, 7, id);
            id = notifyIfNeeded(context, nm, v, "Kasko poliçesi", v.cascoExpiry, 7, id);
            id = notifyIfNeeded(context, nm, v, "Koltuk sigortası", v.seatExpiry, 7, id);
        }
    }

    private int notifyIfNeeded(Context context, NotificationManager nm, Vehicle v, String label, long expiry, int threshold, int id) {
        if (expiry <= 0) return id;
        long days = daysUntil(expiry);
        if (days > threshold) return id;
        String text = days < 0 ? label + " süresi " + (-days) + " gün önce geçti." : label + " için " + days + " gün kaldı.";
        Intent launch = new Intent(context, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(context, id, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification n = new android.app.Notification.Builder(context, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(v.plate + " • " + label)
                .setContentText(text)
                .setAutoCancel(true).setContentIntent(pi).build();
        nm.notify(id, n);
        return id + 1;
    }

    private long daysUntil(long millis) {
        LocalDate today = LocalDate.now();
        LocalDate date = java.time.Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate();
        return ChronoUnit.DAYS.between(today, date);
    }
}
