# Araç Takip v1.0 — APK Oluşturma

## Android Studio ile
1. Android Studio'yu açın.
2. **Open** seçeneğiyle bu klasörü seçin.
3. Proje senkronizasyonunun tamamlanmasını bekleyin.
4. Menüden **Build > Build App Bundle(s) / APK(s) > Build APK(s)** seçin.
5. Oluşan dosya: `app/build/outputs/apk/debug/app-debug.apk`

Gerekli ortam: JDK 17, Android SDK API 37 ve Android Gradle Plugin 9.2.x ile uyumlu Gradle.

## GitHub Actions ile
Projeyi GitHub deposuna yükleyin. `.github/workflows/build-apk.yml` otomatik olarak APK üretir.
Actions ekranındaki **Build APK** iş akışından `AracTakip-debug-apk` çıktısını indirebilirsiniz.

## Uygulama özellikleri
- Plaka
- Marka
- Model
- Trafik poliçesi bitiş tarihi
- Kasko poliçesi bitiş tarihi
- Koltuk sigortası bitiş tarihi
- Muayene bitiş tarihi
- Muayene için 30 gün kala uyarı
- Poliçeler için 7 gün kala uyarı
- Yaklaşan süreler ekranı
- Süresi geçenler ekranı
- Telefonda yerel kayıt
